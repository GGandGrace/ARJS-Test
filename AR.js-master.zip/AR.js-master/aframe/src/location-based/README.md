# Original location-based components

These are the original location-based components, developed in 2020 or before. Please note that new location-based A-Frame components, wrapping the [three.js location-based API](https://github.com/AR-js-org/AR.js/tree/master/three.js/src/location-based), are available [here](../new-location-based). 

The new components are likely to see more active development and bug-fixes so it is recommended to try these first, and if they do not work for you, try these original components instead.
