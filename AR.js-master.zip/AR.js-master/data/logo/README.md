Original logo by @tentone or on twitter [@tentone](https://twitter.com/tentonej)
Released under [MIT license](https://github.com/jeromeetienne/AR.js/issues/4#issuecomment-281746031)
