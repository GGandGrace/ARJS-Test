- make a page with the player and the learner in the same page
  - better user experience as there is no page reload
  - no issue with fullscreen exiting when reloading page
  - thus faster for the user

# Feature: test the marker on the page with a qr-code
- would be good if i could try immediatly the marker
- like a way to load a page with a marker in the url
- say i got a page able to do read the marker file from a url
- can artoolkit read it from a data url ?
