import Source from "./arjs-source";

const ArToolkitSource = Source;

export default ArToolkitSource;
